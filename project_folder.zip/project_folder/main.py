from file_operations import*
action = 0
while True:
    action = int(input("""--- Меню ---
1. Показать фильмы
2. Добавить фильм
3. Выход
Выберите действие(1/2/3): """))
    if action == 1:
        show_movies()
    elif action == 2:
        add_movies()
    else:
        print("Выход из программы!")
        break






