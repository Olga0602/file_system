def add_movies():
    with open("project_folder/movie.txt", "a", encoding="utf-8") as file:
        name_movie = input("Введите название фильма,жанр и рейтинг через запятую: ")
        file.write(f"{name_movie}\n")
        print("Фильм успешно добавлен!")


def show_movies():
    with open("project_folder/movie.txt", "r", encoding="utf-8") as file:
     for line in file:
       line = line.split(",")
       movie = line
       print(f"{movie[0]}. Жанр:{movie[1]}. Рейтинг:{movie[2].strip()}")

