from products_operations import*
action = 0
load_products()
while True:
    action = int(input("""--- Админ-панель магазина ---
1. Показать товары
2. Добавить товар
3. Удалить товар
4. Выход
Выберите действие(1/2/3/4): """))
    if action == 1:
        show_products()
    elif action == 2:
        add_products()
    elif action == 3:
        delete_ptoduct()
    else:
       save_products()
       break
