products = []
def load_products():
    with open("project_folder2/products.txt", "r", encoding="utf-8") as file:
         for line in file:
            line = line.split(",")
            if len(line) == 3:
                 product = {
                    "name":line[0],
                    "price":line[1],
                    "count":line[2].strip()
                 }
                 products.append(product)
            else: 
                print("Список товаров пуст")
         print(products)

def save_products():
    with open("project_folder2/products.txt", "w", encoding="utf-8") as file:
          for i in range(len(products)):
                file.write(f"{products[i]["name"]},{products[i]["price"]},{products[i]["count"]}\n")

def show_products():
     print(products)

def add_products():
    line = input("Введите название,стоимость,количество товара через запятую: ")
    line = line.split(",")
    product = {
         "name":line[0],
         "price":line[1],
         "count":line[2]
        }
    products.append(product)

def delete_ptoduct():
    name = input("Введите название продукта которого хотите удалить: ")
    for i in range(len(products)-1):
        if name == products[i]["name"]:
            del products[i]
            return
    print("Продукта с таким названием нет")

